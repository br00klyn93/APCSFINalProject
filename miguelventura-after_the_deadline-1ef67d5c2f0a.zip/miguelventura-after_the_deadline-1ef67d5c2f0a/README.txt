After the Deadline helper classes for Python
Author: Miguel Ventura
License: MIT

Ideas and contributions are welcome.